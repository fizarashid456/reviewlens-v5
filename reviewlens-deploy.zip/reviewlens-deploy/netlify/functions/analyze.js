exports.handler = async function(event, context) {
  // Only allow POST
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const { review, lang } = JSON.parse(event.body);

    if (!review || review.trim().length < 3) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Review text too short' })
      };
    }

    const SYSTEM_PROMPT = `You are an expert AI system detecting fake and genuine product reviews. Return ONLY valid JSON:
{"verdict":"FAKE"|"GENUINE"|"UNCERTAIN","confidence":0-100,"signals":["s1","s2","s3"],"explanation":"2-3 sentences.","features":{"sentiment_extreme":0-100,"specificity":0-100,"language_pattern":0-100,"length_score":0-100,"repetition":0-100,"template_likeness":0-100}}`;

    const langNote = lang && lang !== 'en'
      ? ` Review may be in ${{ ur: 'Urdu', hi: 'Hindi', ar: 'Arabic' }[lang] || lang}. Translate internally.`
      : '';

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: SYSTEM_PROMPT + langNote,
        messages: [{ role: 'user', content: 'Analyze:\n\n' + review }]
      })
    });

    const data = await response.json();
    const raw = data.content?.[0]?.text || '{}';
    const result = JSON.parse(raw.replace(/```json|```/g, '').trim());

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify(result)
    };

  } catch (error) {
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: 'Analysis failed. Please try again.' })
    };
  }
};
