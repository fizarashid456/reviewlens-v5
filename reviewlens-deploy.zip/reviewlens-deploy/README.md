# ReviewLens OS v5 — Deployment Guide

## Files Structure
```
reviewlens-deploy/
├── index.html              ← Main app
├── netlify.toml            ← Netlify config
└── netlify/
    └── functions/
        └── analyze.js      ← Secure API proxy
```

## Deploy karne ka tarika

### Step 1 — Netlify account banao
- netlify.com par jao
- Free account banao

### Step 2 — GitHub se connect karo
- "Import from Git" click karo
- GitHub select karo
- Yeh folder upload karo as new repository

### Step 3 — API Key add karo (SECURE)
- Netlify Dashboard → Site Settings
- Environment Variables → Add variable:
  - Key:   ANTHROPIC_API_KEY
  - Value: sk-ant-xxxxxxxx (aapki key)

### Step 4 — Deploy!
- Automatically deploy hoga
- URL milegi: https://your-site.netlify.app

## API Key kahan se milegi?
console.anthropic.com → API Keys → Create Key
